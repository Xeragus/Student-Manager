export const listStudents = () => {
    return [
        {
            firstName: 'John',
            lastName: 'Doe',
            studentId: '1239189',
            direction: 'KTI'
        },
        {
            firstName: 'Pablo',
            lastName: 'Escobar',
            studentId: '123901203',
            direction: 'KNI'
        },
        {
            firstName: 'El',
            lastName: 'Chapo',
            studentId: '12390120311',
            direction: 'KTI'
        },
        {
            firstName: 'Maximo',
            lastName: 'Rodriguez',
            studentId: '828289',
            direction: 'AAI'
        },
        {
            firstName: 'Julio',
            lastName: 'Inglesias',
            studentId: '82828911',
            direction: 'SSS'
        },
    ];
}